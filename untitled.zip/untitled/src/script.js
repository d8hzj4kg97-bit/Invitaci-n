// ===== ELEMENTOS =====

const envelope = document.getElementById("openEnvelope");
const loading = document.getElementById("loading-screen");
const letter = document.getElementById("letter");

const yes = document.getElementById("yes");
const no = document.getElementById("no");
const success = document.getElementById("success");

// ===== ABRIR SOBRE =====

envelope.addEventListener("click",()=>{

loading.classList.add("hidden");

letter.classList.remove("hidden");

});

// ===== BOTÓN NO =====

function moveButton(){

const x=Math.random()*(window.innerWidth-160);

const y=Math.random()*(window.innerHeight-90);

no.style.position="fixed";

no.style.left=x+"px";

no.style.top=y+"px";

}

no.addEventListener("mouseover",moveButton);

no.addEventListener("click",moveButton);

// ===== BOTÓN SÍ =====

yes.addEventListener("click",()=>{

document.querySelector(".buttons").style.display="none";

success.classList.remove("hidden");

celebration();

});

// ===== CELEBRACIÓN =====

function celebration(){

for(let i=0;i<120;i++){

const heart=document.createElement("div");

const icons=[
"❤️",
"💖",
"💕",
"🌸",
"✨",
"🌹"
];

heart.innerHTML=
icons[Math.floor(Math.random()*icons.length)];

heart.style.position="fixed";

heart.style.left=Math.random()*100+"vw";

heart.style.top="-30px";

heart.style.fontSize=(20+Math.random()*30)+"px";

heart.style.transition="6s linear";

document.body.appendChild(heart);

setTimeout(()=>{

heart.style.top="110vh";

heart.style.transform=
`rotate(${Math.random()*720}deg)`;

},50);

setTimeout(()=>{

heart.remove();

},6500);

}

}